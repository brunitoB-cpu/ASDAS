# Dedsafio Anims (Forge 1.21.1)

Mod fan con animaciones al estilo Dedsafio 4. Funciona del lado del servidor
(los jugadores no necesitan nada extra salvo tener el mod si el server lo exige).

## Comandos (requieren OP nivel 2)

- `/dedsafio reviil [jugador]` - Momento Reviil: levitacion, espiral de luz, explosion final y titulo.
- `/dedsafio spin [jugador]` - giro con anillo de fuego de alma.
- `/dedsafio aura [jugador]` - aura con anillos expansivos.
- `/dedsafio stop [jugador]` - detiene la animacion.

## Compilar

1. Java 21 instalado.
2. En esta carpeta: `./gradlew build` (o `gradle wrapper` primero si no tienes el wrapper).
3. El .jar queda en `build/libs/`. Copialo a la carpeta `mods` de Forge 1.21.1.

Si Gradle pide otra version de Forge, cambia `forge_version` en `gradle.properties`
por la que muestre tu instalador de Forge 1.21.1.

## Personalizar

Todas las animaciones estan en `src/main/java/com/dedsafio/anims/anim/AnimationType.java`.
Cambia duracion, particulas, sonidos y efectos para acercarlas a las del video.
