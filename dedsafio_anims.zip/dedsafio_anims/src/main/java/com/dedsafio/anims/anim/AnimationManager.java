package com.dedsafio.anims.anim;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Lleva la cuenta de las animaciones activas y las avanza cada tick del servidor. */
public class AnimationManager {

    private static final Map<UUID, Active> ACTIVE = new ConcurrentHashMap<>();

    private static final class Active {
        final ServerPlayer player;
        final AnimationType type;
        int tick = 0;

        Active(ServerPlayer player, AnimationType type) {
            this.player = player;
            this.type = type;
        }
    }

    public static void play(ServerPlayer player, AnimationType type) {
        ACTIVE.put(player.getUUID(), new Active(player, type));
        type.start((ServerLevel) player.level(), player);
    }

    public static void stop(ServerPlayer player) {
        ACTIVE.remove(player.getUUID());
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Iterator<Active> it = ACTIVE.values().iterator();
        while (it.hasNext()) {
            Active a = it.next();
            if (a.player.hasDisconnected() || !a.player.isAlive() || a.tick >= a.type.duration()) {
                it.remove();
                continue;
            }
            a.type.tick((ServerLevel) a.player.level(), a.player, a.tick);
            a.tick++;
        }
    }
}
