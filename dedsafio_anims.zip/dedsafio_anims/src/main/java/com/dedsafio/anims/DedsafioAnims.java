package com.dedsafio.anims;

import com.dedsafio.anims.anim.AnimationManager;
import com.dedsafio.anims.command.DedsafioCommand;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(DedsafioAnims.MOD_ID)
public class DedsafioAnims {
    public static final String MOD_ID = "dedsafio_anims";

    public DedsafioAnims() {
        MinecraftForge.EVENT_BUS.register(new AnimationManager());
        MinecraftForge.EVENT_BUS.register(new DedsafioCommand());
    }
}
