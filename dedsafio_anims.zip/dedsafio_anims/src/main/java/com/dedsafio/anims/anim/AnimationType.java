package com.dedsafio.anims.anim;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Animaciones disponibles. Cada una se ejecuta tick a tick en el servidor,
 * asi funcionan tambien en servidores dedicados sin codigo de cliente.
 * Edita duraciones, particulas y sonidos aqui para ajustarlas al video.
 */
public enum AnimationType {

    /** "Momento Reviil": el jugador se eleva, espiral de luz y explosion final. */
    REVIIL(100) {
        @Override
        public void start(ServerLevel level, ServerPlayer p) {
            p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 50, 20));
            p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("MOMENTO REVIIL")));
            p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("Dedsafio 4")));
            p.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 70, 0, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
            level.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.6f);
        }

        @Override
        public void tick(ServerLevel level, ServerPlayer p, int t) {
            // Espiral ascendente alrededor del jugador.
            double angle = t * 0.5;
            double radius = 1.2 - Math.min(t, 70) * 0.008;
            for (int i = 0; i < 3; i++) {
                double a = angle + i * (Math.PI * 2 / 3);
                level.sendParticles(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(a) * radius,
                        p.getY() + 0.1 + (t % 40) * 0.05,
                        p.getZ() + Math.sin(a) * radius,
                        1, 0, 0, 0, 0.0);
            }
            if (t == 70) {
                level.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1, p.getZ(), 1, 0, 0, 0, 0);
                level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(),
                        120, 0.6, 0.8, 0.6, 0.6);
                level.playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0f, 1.0f);
                p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, false, false));
            }
        }
    },

    /** El jugador gira sobre si mismo con anillo de fuego de alma. */
    SPIN(60) {
        @Override
        public void start(ServerLevel level, ServerPlayer p) {
            level.playSound(null, p.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 0.6f, 1.6f);
        }

        @Override
        public void tick(ServerLevel level, ServerPlayer p, int t) {
            p.connection.teleport(p.getX(), p.getY(), p.getZ(), p.getYRot() + 24f, p.getXRot());
            for (int i = 0; i < 8; i++) {
                double a = i * (Math.PI / 4) + t * 0.3;
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                        p.getX() + Math.cos(a) * 1.5, p.getY() + 1, p.getZ() + Math.sin(a) * 1.5,
                        1, 0, 0, 0, 0);
            }
        }
    },

    /** Aura pulsante que se expande en anillos. */
    AURA(100) {
        @Override
        public void start(ServerLevel level, ServerPlayer p) {
            p.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
            level.playSound(null, p.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 0.8f, 0.8f);
        }

        @Override
        public void tick(ServerLevel level, ServerPlayer p, int t) {
            if (t % 10 == 0) {
                double r = 0.5 + (t / 10) * 0.35;
                for (int i = 0; i < 24; i++) {
                    double a = i * (Math.PI * 2 / 24);
                    level.sendParticles(ParticleTypes.END_ROD,
                            p.getX() + Math.cos(a) * r, p.getY() + 0.2, p.getZ() + Math.sin(a) * r,
                            1, 0, 0.02, 0, 0.01);
                }
            }
        }
    };

    private final int duration;

    AnimationType(int duration) {
        this.duration = duration;
    }

    public int duration() {
        return duration;
    }

    public abstract void start(ServerLevel level, ServerPlayer player);

    public abstract void tick(ServerLevel level, ServerPlayer player, int tick);
}
