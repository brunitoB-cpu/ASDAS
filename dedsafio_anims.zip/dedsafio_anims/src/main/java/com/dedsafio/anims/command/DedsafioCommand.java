package com.dedsafio.anims.command;

import com.dedsafio.anims.anim.AnimationManager;
import com.dedsafio.anims.anim.AnimationType;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Locale;

/**
 * /dedsafio <reviil|spin|aura> [jugador]
 * /dedsafio stop [jugador]
 */
public class DedsafioCommand {

    @SubscribeEvent
    public void onRegister(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("dedsafio")
                .requires(src -> src.hasPermission(2));

        for (AnimationType type : AnimationType.values()) {
            root.then(Commands.literal(type.name().toLowerCase(Locale.ROOT))
                    .executes(ctx -> run(ctx.getSource(), ctx.getSource().getPlayerOrException(), type))
                    .then(Commands.argument("jugador", EntityArgument.player())
                            .executes(ctx -> run(ctx.getSource(),
                                    EntityArgument.getPlayer(ctx, "jugador"), type))));
        }

        root.then(Commands.literal("stop")
                .executes(ctx -> {
                    AnimationManager.stop(ctx.getSource().getPlayerOrException());
                    return 1;
                })
                .then(Commands.argument("jugador", EntityArgument.player())
                        .executes(ctx -> {
                            AnimationManager.stop(EntityArgument.getPlayer(ctx, "jugador"));
                            return 1;
                        })));

        d.register(root);
    }

    private int run(CommandSourceStack src, ServerPlayer target, AnimationType type) {
        AnimationManager.play(target, type);
        src.sendSuccess(() -> Component.literal("Animacion " + type.name().toLowerCase(Locale.ROOT)
                + " iniciada en " + target.getName().getString()), true);
        return 1;
    }
}
